class Config:
    SECRET_KEY = "clave_segura"
    ORACLE_USER = "ADMINLOGISTIC"
    ORACLE_PASSWORD = "Zseries2026"
    ORACLE_DSN = "192.168.157.137/XEPDB1"
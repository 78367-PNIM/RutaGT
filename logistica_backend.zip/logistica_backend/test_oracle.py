import oracledb

conn = oracledb.connect(
    user="ADMINLOGISTIC",
    password="Zseries2026",
    dsn="192.168.157.137:1521/XEPDB1"
)

cur = conn.cursor()
cur.execute("SELECT sysdate FROM dual")
print(cur.fetchone())

cur.execute("SELECT COUNT(*) FROM ENVIO")
print(cur.fetchone())
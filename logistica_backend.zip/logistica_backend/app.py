from flask import Flask, jsonify
from flask_jwt_extended import JWTManager
from config import Config
from database.db import get_connection

# 🔽 IMPORTAR BLUEPRINT
from auth.auth_routes import auth_bp
from asignacion.asignacion_routes import asignacion_bp
from rastreo.rastreo_routes import rastreo_bp
from flask_cors import CORS

app = Flask(__name__)
app.config.from_object(Config)
app.register_blueprint(rastreo_bp)

CORS(app)

jwt = JWTManager(app)

# 🔽 REGISTRAR BLUEPRINT
app.register_blueprint(auth_bp)
app.register_blueprint(asignacion_bp)

@app.route("/")
def home():
    return {"status": "OK"}

@app.route("/test-oracle")
def test_oracle():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT SYSDATE FROM DUAL")
    fecha = cur.fetchone()[0]
    cur.close()
    conn.close()
    return {"oracle_fecha": str(fecha)}

if __name__ == "__main__":
    app.run(debug=True)

from flask import Blueprint, request, jsonify
from database.db import get_connection
from flask_jwt_extended import jwt_required, get_jwt_identity

envio_bp = Blueprint('envio', __name__)

@envio_bp.route('/envios', methods=['POST'])
@jwt_required()
def crear_envio():
    data = request.json
    usuario = get_jwt_identity()

    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        INSERT INTO ENVIO (CODIGO, ID_RUTA, ESTADO, PRIORIDAD)
        VALUES (:codigo, :ruta, 'CREADO', :prioridad)
        RETURNING ID_ENVIO INTO :id_envio
    """, {
        "codigo": data['codigo'],
        "ruta": data['id_ruta'],
        "prioridad": data['prioridad'],
        "id_envio": cur.var(int)
    })

    conn.commit()

    id_envio = cur.getvalue("id_envio")[0]

    return jsonify({"msg": "Envío creado", "id_envio": id_envio})
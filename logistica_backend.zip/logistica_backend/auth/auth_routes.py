from flask import Blueprint, request, jsonify
from database.db import get_connection
from flask_jwt_extended import create_access_token
import bcrypt

auth_bp = Blueprint("auth", __name__)

@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.json
    username = data.get("username")
    password = data.get("password")

    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        SELECT ID_USUARIO, PASSWORD_HASH, ROL
        FROM USUARIO
        WHERE USERNAME = :username
        AND ESTADO = 'ACTIVO'
    """, {"username": username})

    row = cur.fetchone()
    cur.close()
    conn.close()

    if not row:
        return jsonify({"msg": "Usuario no encontrado"}), 401

    if bcrypt.checkpw(password.encode(), row[1].encode()):
        token = create_access_token(identity=username)
        return jsonify(access_token=token)

    return jsonify({"msg": "Credenciales incorrectas"}), 401
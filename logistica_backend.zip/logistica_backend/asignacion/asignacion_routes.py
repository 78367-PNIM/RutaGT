from flask import Blueprint, request, jsonify
from database.db import get_connection
from flask_jwt_extended import jwt_required, get_jwt_identity
from auditoria.auditoria import registrar_auditoria

asignacion_bp = Blueprint('asignacion', __name__)

@asignacion_bp.route('/asignar', methods=['POST'])
@jwt_required()
def crear_asignacion():
    data = request.json
    usuario = get_jwt_identity()

    conn = get_connection()
    cur = conn.cursor()
    id_asig_var = cur.var(int)

    try:
        # 🔒 1. BLOQUEO DE VEHÍCULO
        cur.execute("""
            SELECT ID_VEHICULO
            FROM VEHICULO
            WHERE ID_VEHICULO = :vehiculo
            AND ESTADO = 'DISPONIBLE'
            FOR UPDATE NOWAIT
        """, {"vehiculo": data["id_vehiculo"]})

        if not cur.fetchone():
            return jsonify({"msg": "Vehículo no disponible"}), 409

        # 🔒 2. BLOQUEO DE OPERADOR
        cur.execute("""
            SELECT ID_OPERADOR
            FROM OPERADOR
            WHERE ID_OPERADOR = :operador
            AND ESTADO = 'ACTIVO'
            FOR UPDATE NOWAIT
        """, {"operador": data["id_operador"]})

        if not cur.fetchone():
            return jsonify({"msg": "Operador no disponible"}), 409

        # ✅ 3. CREAR ASIGNACIÓN
        cur.execute("""
            INSERT INTO ASIGNACION (
                ID_OPERADOR,
                ID_VEHICULO,
                ID_RUTA,
                FECHA_ENTREGA_INICIO,
                FECHA_ENTREGA_FIN,
                ESTADO,
                FECHA_ASIGNACION
            ) VALUES (
                :operador,
                :vehiculo,
                :ruta,
                TRUNC(TO_DATE(:inicio, 'YYYY-MM-DD')),
                TRUNC(TO_DATE(:fin, 'YYYY-MM-DD')),
                'PLANIFICADA',
                TRUNC(TO_DATE(:inicio, 'YYYY-MM-DD'))
            )
            RETURNING ID_ASIGNACION INTO :id_asig
        """, {
            "operador": data["id_operador"],
            "vehiculo": data["id_vehiculo"],
            "ruta": data["id_ruta"],
            "inicio": data["fecha_inicio"],
            "fin": data["fecha_fin"],
            "id_asig": id_asig_var
        })

        id_asig = id_asig_var.getvalue()[0]

        # 🔄 4. CAMBIAR ESTADOS
        cur.execute("""
            UPDATE VEHICULO SET ESTADO = 'EN_RUTA'
            WHERE ID_VEHICULO = :vehiculo
        """, {"vehiculo": data["id_vehiculo"]})

        cur.execute("""
            UPDATE OPERADOR SET ESTADO = 'ACTIVO'
            WHERE ID_OPERADOR = :operador
        """, {"operador": data["id_operador"]})

        # 🧾 5. AUDITORÍA
        registrar_auditoria(
            conn,
            "ASIGNACION",
            id_asig,
            usuario,
            "INSERT",
            "Asignación creada con bloqueo Oracle"
        )

        conn.commit()

        return jsonify({
            "msg": "Asignación creada",
            "id_asignacion": id_asig
        })

    except Exception as e:
        conn.rollback()
        return jsonify({
            "error": "Conflicto de concurrencia",
            "detalle": str(e)
        }), 409

    finally:
        cur.close()
        conn.close()

@asignacion_bp.route('/finalizar', methods=['POST'])
@jwt_required()
def finalizar_asignacion():
    data = request.json
    usuario = get_jwt_identity()

    conn = get_connection()
    cur = conn.cursor()

    try:
        # 1️⃣ Bloquear la asignación
        cur.execute("""
            SELECT ID_VEHICULO, ID_OPERADOR
            FROM ASIGNACION
            WHERE ID_ASIGNACION = :id_asig
            AND ESTADO IN ('PLANIFICADA', 'EN_EJECUCION')
            FOR UPDATE
        """, {"id_asig": data["id_asignacion"]})

        row = cur.fetchone()
        if not row:
            return jsonify({"msg": "Asignación no válida o ya finalizada"}), 404

        id_vehiculo, id_operador = row

        # 2️⃣ Finalizar la asignación
        cur.execute("""
            UPDATE ASIGNACION
            SET ESTADO = 'FINALIZADA'
            WHERE ID_ASIGNACION = :id_asig
        """, {"id_asig": data["id_asignacion"]})

        # 3️⃣ Liberar vehículo
        cur.execute("""
            UPDATE VEHICULO
            SET ESTADO = 'DISPONIBLE'
            WHERE ID_VEHICULO = :vehiculo
        """, {"vehiculo": id_vehiculo})

        # 4️⃣ (Opcional) operador sigue ACTIVO
        # Si en tu modelo el operador nunca cambia, no hagas nada aquí

        # 5️⃣ Auditoría
        registrar_auditoria(
            conn,
            "ASIGNACION",
            data["id_asignacion"],
            usuario,
            "UPDATE",
            "Asignación finalizada"
        )

        conn.commit()

        return jsonify({
            "msg": "Asignación finalizada correctamente"
        })

    except Exception as e:
        conn.rollback()
        return jsonify({
            "error": "Error al finalizar asignación",
            "detalle": str(e)
        }), 500

    finally:
        cur.close()
        conn.close()
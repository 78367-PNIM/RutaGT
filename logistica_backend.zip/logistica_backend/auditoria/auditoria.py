def registrar_auditoria(conn, tabla, id_afectado, usuario, accion, detalle):
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO BITACORA_AUDITORIA
        (TABLA, ID_AFECTADO, USUARIO, ACCION, FECHA, DETALLE)
        VALUES (:tabla, :id, :usuario, :accion, SYSDATE, :detalle)
    """, {
        "tabla": tabla,
        "id": id_afectado,
        "usuario": usuario,
        "accion": accion,
        "detalle": detalle
    })
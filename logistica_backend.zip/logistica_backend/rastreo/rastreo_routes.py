from flask import Blueprint, jsonify
from database.db import get_connection

rastreo_bp = Blueprint('rastreo', __name__)

@rastreo_bp.route('/rastreo/<codigo>', methods=['GET'])
def rastrear_envio_avanzado(codigo):
    conn = get_connection()
    cur = conn.cursor()

    # 1️⃣ Obtener encabezado del envío
    cur.execute("""
        SELECT e.ID_ENVIO, e.ESTADO, r.ORIGEN, r.DESTINO
        FROM ENVIO e
        JOIN RUTA r ON r.ID_RUTA = e.ID_RUTA
        WHERE UPPER(e.CODIGO) = UPPER(:codigo)
    """, {"codigo": codigo})

    envio = cur.fetchone()
    if not envio:
        return jsonify({"msg": "Envío no encontrado"}), 404

    id_envio, estado_envio, origen, destino = envio

    # 2️⃣ Obtener historial de nodos
    cur.execute("""
        SELECT
            rn.ORDEN,
            n.NOMBRE,
            n.TIPO,
            rn.DISTANCIA_TRAMO_KM,
            rn.TIEMPO_ESTIMADO_MIN
        FROM RUTA_NODO rn
        JOIN NODO_LOGISTICO n ON n.ID_NODO = rn.ID_NODO
        WHERE rn.ID_RUTA = (
            SELECT ID_RUTA FROM ENVIO WHERE ID_ENVIO = :id_envio
        )
        ORDER BY rn.ORDEN
    """, {"id_envio": id_envio})

    nodos = []

    for row in cur.fetchall():
        nodos.append({
            "orden": row[0],
            "nodo": row[1],
            "tipo": row[2],
            "distancia_tramo_km": row[3],
            "tiempo_estimado_min": row[4]
        })

    cur.close()
    conn.close()

    return jsonify({
        "codigo_envio": codigo,
        "estado_envio": estado_envio,
        "origen": origen,
        "destino": destino,
        "ruta": nodos
    })